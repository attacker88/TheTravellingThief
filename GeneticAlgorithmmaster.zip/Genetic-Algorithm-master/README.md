# Genetic-Algorithm
Solving Travelling Thief Problem using GA
